"""Rebuild the bundled USDA subset from the official SR Legacy CSV archive.
Usage: python scripts/build_food_catalog.py /path/to/SR-Legacy.zip
Download source: https://fdc.nal.usda.gov/fdc-datasets/FoodData_Central_sr_legacy_food_csv_2018-04.zip
"""
import csv,io,json,sys,zipfile,hashlib
from pathlib import Path
SELECTION=[
(171477,'Poulet','Blanc de poulet rôti, viande sans peau'),
(171078,'Poulet','Blanc de poulet frit, viande sans peau'),
(171077,'Poulet','Blanc de poulet cru, sans peau ni os'),
(168878,'Riz','Riz blanc long grain, cuit'),(168877,'Riz','Riz blanc long grain, cru'),
(169967,'Brocoli','Brocoli bouilli, égoutté, sans sel'),(170379,'Brocoli','Brocoli cru'),
(169737,'Pâtes','Pâtes cuites, sans sel ajouté'),(169736,'Pâtes','Pâtes sèches'),
(175168,'Saumon','Saumon atlantique d’élevage, cuit à chaleur sèche'),
(175167,'Saumon','Saumon atlantique d’élevage, cru'),
(171794,'Bœuf','Bœuf haché 90 % maigre, émietté et cuit à la poêle'),
(174030,'Bœuf','Bœuf haché 90 % maigre, cru'),
(171956,'Poisson','Morue atlantique, cuite à chaleur sèche'),
(171955,'Poisson','Morue atlantique, crue'),
(173424,'Œuf','Œuf entier dur'),(173423,'Œuf','Œuf entier frit'),
(170440,'Pomme de terre','Pomme de terre bouillie sans peau, sans sel'),
(170698,'Frites','Frites de restauration rapide, huile végétale'),
(170393,'Carotte','Carotte crue'),(170394,'Carotte','Carotte bouillie, égouttée, sans sel'),
(170457,'Tomate','Tomate rouge crue'),(169247,'Laitue','Laitue romaine crue'),
(168409,'Concombre','Concombre cru avec peau'),(171705,'Avocat','Avocat cru, chair'),
(172688,'Pain','Pain de blé entier du commerce'),(173414,'Fromage','Fromage cheddar'),
(169251,'Champignon','Champignon blanc cru'),(169252,'Champignon','Champignon blanc bouilli, sans sel'),
(169141,'Haricots verts','Haricots verts bouillis, égouttés, sans sel'),
(168525,'Maïs','Maïs doux jaune bouilli, égoutté, avec sel'),
(175180,'Crevette','Crevettes cuites'),(171970,'Crevette','Crevettes panées et frites'),
(170317,'Pizza','Pizza au fromage, pâte classique, surgelée puis cuite'),
(172971,'Saucisse','Saucisse de porc, précuite puis réchauffée au micro-ondes'),
(172448,'Tofu','Tofu ferme, sulfate de calcium et nigari'),(172451,'Tofu','Tofu frit'),
(171688,'Pomme','Pomme crue avec peau'),(173944,'Banane','Banane crue, chair'),
(167762,'Fraise','Fraises crues'),(169097,'Orange','Orange crue, chair'),
(174683,'Raisins','Raisins rouges ou verts, crus'),
(173740,'Haricots','Haricots rouges bouillis, sans sel'),
(171413,'Huile','Huile d’olive'),(173410,'Beurre','Beurre salé'),
]
NUTRIENTS={'1008':'calories','1003':'protein','1005':'carbs','1004':'fat'}
root=Path(__file__).resolve().parents[1]
archive=Path(sys.argv[1]);z=zipfile.ZipFile(archive)
def read(name):
 path=next(n for n in z.namelist() if n.endswith('/'+name))
 return csv.DictReader(io.TextIOWrapper(z.open(path),encoding='utf-8-sig'))
foods={r['fdc_id']:r for r in read('food.csv')}
selected={str(i) for i,_,_ in SELECTION};values={i:{} for i in selected};portions={i:[] for i in selected}
units={r['id']:r['unit_name'] for r in read('nutrient.csv')}
assert units['1008'].upper()=='KCAL'
assert all(units[k].upper()=='G' for k in ['1003','1004','1005'])
for r in read('food_nutrient.csv'):
 if r['fdc_id'] in selected and r['nutrient_id'] in NUTRIENTS and r['amount']!='':
  values[r['fdc_id']][NUTRIENTS[r['nutrient_id']]]=float(r['amount'])
for r in read('food_portion.csv'):
 if r['fdc_id'] in selected and r['gram_weight'] and r['modifier']:
  portions[r['fdc_id']].append({'description':(r['amount']+' '+r['modifier']).strip(),'grams':float(r['gram_weight'])})
result=[]
for ident,group,label in SELECTION:
 ident=str(ident);assert len(values[ident])==4,(ident,values[ident])
 result.append({'id':ident,'group':group,'label':label,'usdaDescription':foods[ident]['description'],
  'sourceUrl':f'https://fdc.nal.usda.gov/food-details/{ident}/nutrients','per100g':values[ident],
  'portions':portions[ident]})
output={'source':'USDA FoodData Central — SR Legacy, April 2018',
 'downloadUrl':'https://fdc.nal.usda.gov/fdc-datasets/FoodData_Central_sr_legacy_food_csv_2018-04.zip',
 'archiveSha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'basis':'100 g edible portion','foods':result}
(root/'data'/'foods.json').write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(f'Wrote {len(result)} sourced foods')
