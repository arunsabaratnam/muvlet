import React, {useEffect, useRef, useState} from 'react';
import {ActivityIndicator, Image, Pressable, Text, TextInput, View} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import FoodNutrition,{NutrientValues} from './FoodNutrition';
const {summary}=require('./mealNutrition.cjs');
const {validResult, prepareMeal, groupDetections} = require('./recognition.cjs');
const GREEN='#52F273', MUTED='#b6cabc', HISTORY='muvlet.recognized.meals.v2';
const input={color:'#fff',backgroundColor:'#183025',padding:14,borderRadius:10,marginVertical:8};
function Button({label,onPress,disabled=false,secondary=false}) {
 return <Pressable accessibilityRole="button" disabled={disabled} onPress={onPress} style={{backgroundColor:disabled?'#435348':secondary?'#183025':GREEN,padding:16,borderRadius:14,marginVertical:8}}><Text style={{color:secondary?'#fff':'#06110F',textAlign:'center',fontWeight:'700'}}>{label}</Text></Pressable>;
}
export default function Recognition({photo,encoded,onBack,onHome}) {
 const [url,setUrl]=useState(''), [token,setToken]=useState(''), [busy,setBusy]=useState(false);
 const [error,setError]=useState(''), [rows,setRows]=useState([]), [done,setDone]=useState(false);
 const [ratio,setRatio]=useState(1), [saved,setSaved]=useState(false), [history,setHistory]=useState([]);
 const [saving,setSaving]=useState(false);
 const nutritionSummary=summary(rows);
 const controller=useRef(null), lock=useRef(false), mounted=useRef(true), sequence=useRef(0);
 useEffect(()=>{
  mounted.current=true;
  AsyncStorage.getItem('muvlet.recognition.url').then(v=>{if(v&&mounted.current)setUrl(v);}).catch(()=>{});
  AsyncStorage.getItem(HISTORY).then(v=>{const a=v?JSON.parse(v):[];if(Array.isArray(a)&&mounted.current)setHistory(a);}).catch(()=>{});
  return ()=>{mounted.current=false;controller.current?.abort();};
 },[]);
 function edit(id,patch){setRows(old=>old.map(r=>r.id===id?{...r,...patch}:r));setSaved(false);setError('');}
 function add(){setRows(old=>[...old,{id:`manual-${++sequence.current}`,name:'',grams:'',boxes:[],score:null,source:'manual',confirmed:false}]);setSaved(false);}
 async function recognize(){
  if(lock.current)return;
  const endpoint=url.trim().replace(/\/$/,'');
  const match=endpoint.match(/^http:\/\/(\d{1,3}(?:\.\d{1,3}){3}):8765$/);
  const ip=match?match[1].split('.').map(Number):[];
  if(ip.length!==4||ip.some(n=>n>255)||!(ip[0]===10||(ip[0]===192&&ip[1]===168)||(ip[0]===172&&ip[1]>=16&&ip[1]<=31))){setError('Entre l’adresse locale actuelle du PC, par exemple http://172.20.10.2:8765');return;}
  if(!encoded){setError('Retourne en arrière et reprends une photo.');return;}
  if(!token.trim()){setError('Entre le code affiché dans la fenêtre SERVEUR PRÊT.');return;}
  lock.current=true;setBusy(true);setError('');setRows([]);setDone(false);setSaved(false);
  const abort=new AbortController();controller.current=abort;
  const timer=setTimeout(()=>abort.abort(),180000);
  try{
   const response=await fetch(endpoint+'/recognize',{method:'POST',signal:abort.signal,headers:{'Content-Type':'application/json','X-Muvlet-Token':token.trim()},body:JSON.stringify({image:encoded})});
   const result=await response.json();
   if(!response.ok)throw new Error(result.error||'Analyse impossible.');
   if(result.apiVersion!==2)throw new Error('Ancien serveur détecté. Ferme-le puis lance DEMARRER-RECONNAISSANCE.bat du nouveau dossier.');
   if(!validResult(result))throw new Error('Réponse du serveur invalide.');
   if(!mounted.current)return;
   setRatio(result.imageWidth/result.imageHeight);
   setRows(groupDetections(result.detections));
   setDone(true);
   AsyncStorage.setItem('muvlet.recognition.url',endpoint).catch(()=>{});
  }catch(e){if(mounted.current)setError(e.name==='AbortError'?'Analyse annulée ou délai dépassé. Tu peux réessayer ou saisir les aliments manuellement.':e.message==='Network request failed'?'Connexion impossible. Vérifie le réseau, l’adresse actuelle du PC et le serveur.':e.message);}
  finally{clearTimeout(timer);lock.current=false;if(mounted.current)setBusy(false);}
 }
 async function save(){
  if(lock.current||saved)return;
  let foods;try{foods=prepareMeal(rows);}catch(e){setError(e.message);return;}
  lock.current=true;setSaving(true);
  try{
   const raw=await AsyncStorage.getItem(HISTORY), entries=raw?JSON.parse(raw):[];
   if(!Array.isArray(entries))throw new Error();
   const entry={id:Date.now().toString(),createdAt:new Date().toISOString(),foods,nutrition:summary(rows).total};
   const next=[entry,...entries].slice(0,100);
   await AsyncStorage.setItem(HISTORY,JSON.stringify(next));
   if(mounted.current){setSaved(true);setHistory(next);setError('');}
  }catch{if(mounted.current)setError('Impossible d’enregistrer le repas.');}
  finally{lock.current=false;if(mounted.current)setSaving(false);}
 }
 return <View>
  <Text style={{color:GREEN,fontSize:12,letterSpacing:2}}>PHOTO • PLUSIEURS ALIMENTS</Text>
  <Text style={{color:'#fff',fontSize:28,fontWeight:'700',marginTop:8}}>Que contient mon assiette ?</Text>
  {!!photo&&<View style={{width:'100%',aspectRatio:ratio,marginVertical:16,borderRadius:18,overflow:'hidden',backgroundColor:'#183025'}}>
   <Image source={{uri:photo}} resizeMode="contain" style={{width:'100%',height:'100%'}}/>
   {done&&rows.flatMap((r,i)=>r.boxes.map((box,j)=><View pointerEvents="none" key={`${r.id}-${j}`} style={{position:'absolute',left:`${box[0]*100}%`,top:`${box[1]*100}%`,width:`${(box[2]-box[0])*100}%`,height:`${(box[3]-box[1])*100}%`,borderWidth:2,borderColor:r.confirmed?GREEN:'#ffd479'}}><Text style={{backgroundColor:r.confirmed?GREEN:'#ffd479',color:'#06110F',alignSelf:'flex-start',paddingHorizontal:5,fontWeight:'800'}}>{i+1}</Text></View>))}
  </View>}
  {!!photo&&<><Text style={{color:MUTED,lineHeight:21}}>Le détecteur cherche plusieurs aliments visibles parmi 30 catégories. Vérifie chaque proposition : il peut oublier ou confondre des aliments. Les ingrédients cachés et les quantités ne sont pas mesurés.</Text>
  <Text style={{color:'#fff',marginTop:18,fontWeight:'700'}}>Connexion à ton ordinateur</Text>
  <TextInput editable={!busy&&!saving} accessibilityLabel="Adresse du serveur" value={url} onChangeText={setUrl} placeholder="http://172.20.10.2:8765" placeholderTextColor={MUTED} autoCapitalize="none" autoCorrect={false} style={input}/>
  <TextInput editable={!busy&&!saving} accessibilityLabel="Code de connexion" value={token} onChangeText={setToken} placeholder="Code affiché dans SERVEUR PRÊT" placeholderTextColor={MUTED} autoCapitalize="none" autoCorrect={false} style={input}/>
  <Text style={{color:MUTED,fontSize:12}}>En appuyant sur Analyser, tu envoies la photo à ton ordinateur. Elle n’est pas enregistrée par le serveur.</Text>
  <Button label={done?'Recommencer l’analyse':'Analyser les aliments'} onPress={recognize} disabled={busy||saving}/>
  {busy&&<><ActivityIndicator color={GREEN}/><Text style={{color:'#fff',marginTop:8}}>Analyse sur ton ordinateur… Cela peut prendre plusieurs minutes.</Text><Button secondary label="Annuler l’analyse" onPress={()=>controller.current?.abort()}/></>}
  </>}
  {!!error&&<Text accessibilityRole="alert" style={{color:'#ffb6a9',marginVertical:12}}>{error}</Text>}
  {done&&rows.length===0&&<Text style={{color:'#ffd479'}}>Aucun aliment reconnu avec suffisamment de confiance. Essaie une photo nette, ou ajoute les aliments ci-dessous.</Text>}
  {rows.length>0&&<Text style={{color:'#fff',fontSize:20,fontWeight:'700',marginTop:18}}>Vérifier les aliments ({rows.length})</Text>}
  {rows.map((r,i)=><View key={r.id} style={{backgroundColor:'#10251b',padding:14,borderRadius:16,marginTop:12}}>
   <Text style={{color:GREEN,fontWeight:'700'}}>ALIMENT {i+1}{r.score!==null?` · score du modèle ${Math.round(r.score*100)} %`:' · ajouté manuellement'}</Text>
   <TextInput editable={!saving&&!busy} accessibilityLabel={`Nom de l’aliment ${i+1}`} value={r.name} onChangeText={v=>edit(r.id,{name:v,foodId:null,custom:{},grams:'',quantitySource:'user',portionDescription:null,confirmed:false})} placeholder="Nom de l’aliment" placeholderTextColor={MUTED} style={input}/>
   <FoodNutrition row={r} disabled={saving||busy} onChange={patch=>edit(r.id,patch)}/>
   <Pressable accessibilityRole="checkbox" accessibilityState={{checked:r.confirmed}} disabled={saving||busy} onPress={()=>edit(r.id,{confirmed:!r.confirmed})} style={{paddingVertical:14}}><Text style={{color:r.confirmed?GREEN:'#fff'}}>{r.confirmed?'☑ Aliment, fiche et quantité confirmés':'☐ Je confirme l’aliment, la fiche et la quantité'}</Text></Pressable>
   <Button secondary label="Supprimer cet aliment" disabled={saving||busy} onPress={()=>{setRows(old=>old.filter(x=>x.id!==r.id));setSaved(false);}}/>
  </View>)}
  <Button secondary label="+ Ajouter un aliment oublié" disabled={busy||saving||rows.length>=20} onPress={add}/>
  {rows.length>0&&<><Text style={{color:'#fff',fontSize:22,fontWeight:'700',marginTop:20}}>{nutritionSummary.complete?'Total estimé du repas':'Sous-total incomplet'}</Text><Text style={{color:MUTED}}>{nutritionSummary.calculated} / {nutritionSummary.count} aliments calculés{nutritionSummary.complete?'':' — renseigne les fiches et quantités manquantes.'}</Text><NutrientValues values={nutritionSummary.total}/><Text style={{color:MUTED,lineHeight:20}}>Valeurs estimées d’après les fiches sélectionnées et les grammes saisis. Pense aux huiles, sauces et garnitures : ajoute-les si elles ne sont pas déjà incluses dans la préparation choisie.</Text><Button label={saving?'Enregistrement…':saved?'Repas enregistré':'Enregistrer le repas calculé'} onPress={save} disabled={busy||saving||saved}/></>}
  {saved&&<Text style={{color:GREEN}}>Aliments, quantités et valeurs nutritionnelles enregistrés. Photo non conservée.</Text>}
  {history.length>0&&<View style={{marginTop:22}}><Text style={{color:'#fff',fontSize:20,fontWeight:'700'}}>Derniers repas confirmés</Text>{history.slice(0,5).map(h=><View key={h.id} style={{paddingVertical:12,borderBottomWidth:1,borderBottomColor:'#274033'}}><Text style={{color:MUTED}}>{new Date(h.createdAt).toLocaleString()}</Text><Text style={{color:'#fff',marginTop:4}}>{(h.foods||[]).map(f=>f.name+(f.grams===null?'':` (${f.grams} g)`)).join(' · ')}</Text>{h.nutrition?<NutrientValues values={h.nutrition}/>:<Text style={{color:MUTED}}>Ancien repas : nutrition non calculée.</Text>}</View>)}</View>}
  {saved&&onHome&&<Button label="Voir mes repas" onPress={onHome}/>}
  <Button secondary label={photo?"Retour à la photo":"Retour à l’accueil"} disabled={saving} onPress={onBack}/>
 </View>;
}
