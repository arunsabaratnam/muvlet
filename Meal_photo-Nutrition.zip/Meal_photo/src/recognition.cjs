function validResult(result) {
 return result?.apiVersion === 2 && Number.isFinite(result.imageWidth) && result.imageWidth > 0 && Number.isFinite(result.imageHeight) && result.imageHeight > 0 && Array.isArray(result.detections) && result.detections.length <= 20 && result.detections.every(d => typeof d.label === 'string' && d.label.trim() && Number.isFinite(d.score) && d.score >= 0 && d.score <= 1 && Array.isArray(d.box) && d.box.length === 4 && d.box.every(n => Number.isFinite(n) && n >= 0 && n <= 1) && d.box[2] > d.box[0] && d.box[3] > d.box[1]);
}
function prepareMeal(rows) {
 if (!rows.length) throw new Error('Ajoute au moins un aliment.');
 return rows.map(row => {
  if (!row.name.trim() || !row.confirmed) throw new Error('Vérifie le nom et confirme chaque aliment.');
  return require('./mealNutrition.cjs').snapshot(row);
 });
}
function groupDetections(detections) {
 const groups = new Map();
 detections.forEach(d => {
  if (!groups.has(d.label)) groups.set(d.label, {id:`detected-${groups.size}`,name:d.label,score:d.score,boxes:[],grams:'',source:'detector',confirmed:false});
  const row=groups.get(d.label);row.boxes.push(d.box);row.score=Math.max(row.score,d.score);
 });
 return [...groups.values()];
}
module.exports = {validResult, prepareMeal, groupDetections};
