// Données de démonstration : elles ne proviennent pas de la photo.
const sample = [
  {id:'chicken',name:'Poulet grillé',grams:120,baseGrams:120,kcal:198,protein:37,carbs:0,fat:5},
  {id:'rice',name:'Riz cuit',grams:150,baseGrams:150,kcal:195,protein:4,carbs:42,fat:1},
  {id:'broccoli',name:'Brocoli',grams:80,baseGrams:80,kcal:28,protein:2,carbs:5,fat:0}
];
function nutrients(food) {
  const ratio=food.grams/food.baseGrams;
  return Object.fromEntries(['kcal','protein','carbs','fat'].map(key=>[key,food[key]*ratio]));
}
function totals(foods) {
  return foods.reduce((sum,f)=>{const n=nutrients(f); for(const k of Object.keys(n))sum[k]+=n[k];sum.grams+=f.grams;return sum;},{kcal:0,protein:0,carbs:0,fat:0,grams:0});
}
function parseQuantity(value) {
  const text=String(value).trim().replace(',','.');
  if(!/^\d+(\.\d{1,2})?$/.test(text))return null;
  const n=Number(text);return n>0&&n<=5000?n:null;
}
module.exports={sample,nutrients,totals,parseQuantity};
