import React,{useState} from 'react';
import {View,Text,TextInput,Pressable,Modal,ScrollView,Linking} from 'react-native';
const {foods,profile,forRow}=require('./mealNutrition.cjs');
const green='#52F273',muted='#b6cabc';
const input={color:'#fff',backgroundColor:'#183025',padding:14,borderRadius:10,marginVertical:8};
const normalize=s=>s.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/œ/g,'oe');
function Action({label,onPress,disabled}){return <Pressable accessibilityRole="button" disabled={disabled} onPress={onPress} style={{padding:12,marginVertical:5,borderRadius:10,borderWidth:1,borderColor:'#43664c'}}><Text style={{color:green}}>{label}</Text></Pressable>;}
export function NutrientValues({values}){
 return <View style={{flexDirection:'row',flexWrap:'wrap',gap:10,marginVertical:12}}>{[['calories','kcal',0],['protein','Protéines (g)',1],['carbs','Glucides (g)',1],['fat','Lipides (g)',1]].map(([key,label,decimals])=><View key={key} style={{minWidth:'44%',flexGrow:1,backgroundColor:'#183025',borderRadius:12,padding:12}}><Text style={{color:green,fontSize:23,fontWeight:'700'}}>{values?values[key].toFixed(decimals):'—'}</Text><Text style={{color:muted,fontSize:12}}>{label}</Text></View>)}</View>;
}
export default function FoodNutrition({row,onChange,disabled}){
 const [open,setOpen]=useState(false),[query,setQuery]=useState(''),[portions,setPortions]=useState(false);
 const p=profile(row),n=forRow(row);
 const matches=foods.filter(f=>normalize(f.group+' '+f.label+' '+f.usdaDescription).includes(normalize(query)));
 function choose(id){onChange({foodId:id,custom:{},grams:'',quantitySource:'user',portionDescription:null,confirmed:false});setPortions(false);setOpen(false);}
 return <View>
  <Text style={{color:'#fff',fontWeight:'700',marginTop:8}}>1. Choisir la préparation</Text>
  <Action disabled={disabled} label={row.foodId==='custom'?'Modifier la fiche nutritionnelle':p?p.label:'Choisir cru, cuit, variété…'} onPress={()=>{setQuery(row.name);setOpen(true);}}/>
  {row.foodId==='custom'&&<View><Text style={{color:muted}}>Recopie les valeurs de l’étiquette pour 100 g, pas pour une portion. Ces valeurs seront identifiées comme saisies par toi.</Text>{[['calories','Énergie (kcal)'],['protein','Protéines (g)'],['carbs','Glucides (g)'],['fat','Lipides (g)']].map(([k,label])=><View key={k}><Text style={{color:'#fff',marginTop:6}}>{label} / 100 g</Text><TextInput accessibilityLabel={`${label} pour 100 grammes de ${row.name}`} editable={!disabled} value={row.custom?.[k]||''} onChangeText={v=>onChange({custom:{...row.custom,[k]:v},confirmed:false})} keyboardType="decimal-pad" placeholder="À renseigner" placeholderTextColor={muted} style={input}/></View>)}</View>}
  {p&&<><Text style={{color:muted,fontSize:12}}>Pour 100 g : {p.per100g.calories} kcal · P {p.per100g.protein} g · G {p.per100g.carbs} g · L {p.per100g.fat} g</Text>{p.sourceUrl&&<Action label="Voir la fiche source USDA" onPress={()=>Linking.openURL(p.sourceUrl).catch(()=>{})}/>}</>}
  <Text style={{color:'#fff',fontWeight:'700',marginTop:12}}>2. Quantité consommée</Text>
  <TextInput editable={!disabled} accessibilityLabel={`Quantité en grammes de ${row.name}`} value={row.grams} onChangeText={v=>onChange({grams:v,quantitySource:'user',portionDescription:null,confirmed:false})} keyboardType="decimal-pad" placeholder="Poids comestible en grammes" placeholderTextColor={muted} style={input}/>
  <Text style={{color:muted,fontSize:12}}>Pèse dans le même état que la fiche choisie (cru ou cuit), sans os, noyau ni partie non consommée.</Text>
  {!!p?.portions?.length&&<><Action disabled={disabled} label={portions?'Masquer les portions indicatives':'Pas de balance ? Choisir une portion indicative'} onPress={()=>setPortions(!portions)}/>{portions&&<><Text style={{color:'#ffd479'}}>Poids moyens USDA, pas mesurés sur la photo. Libellés d’origine en anglais. Choisis uniquement une portion qui correspond à ce que tu manges.</Text>{p.portions.map((part,i)=><Action key={i} disabled={disabled} label={`${part.description} ≈ ${part.grams} g`} onPress={()=>{onChange({grams:String(part.grams),quantitySource:'reference_portion',portionDescription:part.description,confirmed:false});setPortions(false);}}/>)}</>}</>}
  {row.quantitySource==='reference_portion'&&<Text style={{color:'#ffd479'}}>Quantité estimée avec une portion de référence : {row.portionDescription}. Ajuste les grammes si nécessaire.</Text>}
  {n&&<><Text style={{color:'#fff',marginTop:14}}>Estimation pour {n.grams} g</Text><NutrientValues values={n.values}/></>}
  <Modal visible={open} animationType="slide" onRequestClose={()=>setOpen(false)}><View style={{flex:1,backgroundColor:'#06110F',padding:22,paddingTop:58,paddingBottom:30}}>
   <Text style={{color:'#fff',fontSize:24,fontWeight:'700'}}>Fiche nutritionnelle</Text><Text style={{color:muted,marginTop:8}}>45 fiches USDA. Vérifie l’aliment, la variété et la cuisson. La photo ne choisit pas ces détails à ta place.</Text>
   <TextInput accessibilityLabel="Rechercher un aliment dans les fiches USDA" value={query} onChangeText={setQuery} placeholder="Rechercher : riz, poulet, huile…" placeholderTextColor={muted} style={input}/>
   <Action label="Afficher toutes les fiches" onPress={()=>setQuery('')}/>
   <ScrollView keyboardShouldPersistTaps="handled" style={{flex:1}}>{matches.map(f=><Action key={f.id} label={`${f.label} · ${f.per100g.calories} kcal / 100 g`} onPress={()=>choose(f.id)}/>)}{!matches.length&&<Text style={{color:muted}}>Aucune fiche correspondante. Efface la recherche ou saisis les valeurs de ton étiquette.</Text>}</ScrollView>
   <Action label="Saisir les valeurs de mon étiquette pour 100 g" onPress={()=>choose('custom')}/>
   <Action label="Fermer" onPress={()=>setOpen(false)}/>
  </View></Modal>
 </View>;
}
