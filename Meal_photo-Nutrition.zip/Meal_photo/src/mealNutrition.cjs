const catalog=require('../data/foods.json');
const keys=['calories','protein','carbs','fat'];
const foods=catalog.foods;
const byId=new Map(foods.map(f=>[f.id,f]));
function number(value){
 const s=String(value??'').trim().replace(',','.');
 return /^\d+(?:\.\d+)?$/.test(s)?Number(s):NaN;
}
function profile(row){
 if(row.foodId==='custom'){
  const per100g=Object.fromEntries(keys.map(k=>[k,number(row.custom?.[k])]));
  if(keys.some(k=>!Number.isFinite(per100g[k])||per100g[k]<0||per100g[k]>(k==='calories'?2000:100)))return null;
  return {id:'custom',label:'Valeurs saisies pour 100 g',per100g,source:'Saisie utilisateur'};
 }
 const f=byId.get(row.foodId);
 return f?{...f,source:catalog.source}:null;
}
function forRow(row){
 const p=profile(row),grams=number(row.grams);
 if(!p||!Number.isFinite(grams)||grams<=0||grams>5000)return null;
 return {grams,profile:p,values:Object.fromEntries(keys.map(k=>[k,p.per100g[k]*grams/100]))};
}
function summary(rows){
 const total=Object.fromEntries(keys.map(k=>[k,0]));let calculated=0;
 for(const r of rows){const n=forRow(r);if(n){calculated++;keys.forEach(k=>total[k]+=n.values[k]);}}
 return {total:calculated?total:null,calculated,count:rows.length,complete:rows.length>0&&calculated===rows.length};
}
function snapshot(row){
 const n=forRow(row);
 if(!n)throw new Error('Pour chaque aliment, choisis une fiche nutritionnelle et une quantité valide (0 à 5000 g, zéro exclu).');
 return {name:row.name.trim(),grams:n.grams,quantitySource:row.quantitySource||'user',portionDescription:row.quantitySource==='reference_portion'?row.portionDescription:null,source:row.source,
  nutrition:{...n.values,basis:'estimated_from_grams',foodId:n.profile.id,foodLabel:n.profile.label,per100g:n.profile.per100g,source:n.profile.source,sourceUrl:n.profile.sourceUrl||null}};
}
module.exports={foods,keys,number,profile,forRow,summary,snapshot};
