const test=require('node:test'),assert=require('node:assert/strict');
const {foods,forRow,summary,snapshot}=require('../src/mealNutrition.cjs');
test('USDA meal sums without rounding individual rows',()=>{
 const s=summary([{foodId:'171477',grams:'150'},{foodId:'168878',grams:'200'},{foodId:'169967',grams:'100'}]);
 assert.equal(s.complete,true);assert.equal(s.total.calories,542.5);
 assert.ok(Math.abs(s.total.protein-54.29)<.00001);
 assert.ok(Math.abs(s.total.carbs-63.52)<.00001);
 assert.ok(Math.abs(s.total.fat-6.325)<.00001);
});
test('raw and cooked rice use different source data',()=>{
 assert.equal(forRow({foodId:'168877',grams:'100'}).values.calories,365);
 assert.equal(forRow({foodId:'168878',grams:'100'}).values.calories,130);
});
test('missing data is incomplete, never a zero-calorie food',()=>{
 const s=summary([{foodId:'168878',grams:'100'},{foodId:'unknown',grams:'100'}]);
 assert.equal(s.complete,false);assert.equal(s.calculated,1);assert.equal(s.total.calories,130);
 assert.equal(summary([{foodId:'unknown',grams:'100'}]).total,null);
 for(const grams of ['','0','-5','5001','NaN','Infinity'])assert.equal(forRow({foodId:'168878',grams}),null);
});
test('user label data is distinguished from USDA data',()=>{
 const r={name:'Sauce',foodId:'custom',grams:'25',custom:{calories:'200',protein:'1,5',carbs:'5',fat:'19'}};
 const s=snapshot(r);assert.equal(s.nutrition.calories,50);assert.equal(s.nutrition.protein,.375);assert.equal(s.nutrition.source,'Saisie utilisateur');assert.equal(s.nutrition.sourceUrl,null);
 assert.equal(forRow({...r,custom:{...r.custom,fat:''}}),null);
 assert.equal(forRow({...r,custom:{...r.custom,fat:'101'}}),null);
});
test('reference portions preserve their provenance and correct edible gram weights',()=>{
 const egg=foods.find(f=>f.id==='173424');const large=egg.portions.find(p=>p.description==='1 large');assert.equal(large.grams,50);
 const saved=snapshot({name:'Œuf',foodId:egg.id,grams:'150',quantitySource:'reference_portion',portionDescription:'3 large'});
 assert.equal(saved.nutrition.calories,232.5);assert.equal(saved.quantitySource,'reference_portion');
 assert.equal(saved.nutrition.per100g.calories,155);
});
test('all bundled entries have sourced complete values and valid portions',()=>{
 assert.equal(foods.length,45);assert.equal(new Set(foods.map(f=>f.id)).size,foods.length);
 foods.forEach(f=>{assert.ok(f.sourceUrl.includes(f.id));assert.ok(f.usdaDescription);for(const k of ['calories','protein','carbs','fat'])assert.ok(Number.isFinite(f.per100g[k])&&f.per100g[k]>=0);f.portions.forEach(p=>assert.ok(p.grams>0));});
});
