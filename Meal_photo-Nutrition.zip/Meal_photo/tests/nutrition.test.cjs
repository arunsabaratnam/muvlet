const {test}=require('node:test');const assert=require('node:assert/strict');
const {sample,totals,nutrients,parseQuantity}=require('../src/nutrition.cjs');
test('Le repas initial totalise 421 kcal et 350 g',()=>assert.deepEqual(totals(sample),{kcal:421,protein:43,carbs:47,fat:6,grams:350}));
test('Doubler une portion double ses nutriments',()=>assert.deepEqual(nutrients({...sample[0],grams:240}),{kcal:396,protein:74,carbs:0,fat:10}));
test('Valider les grammes et la virgule française',()=>{assert.equal(parseQuantity('120,5'),120.5);for(const value of ['','0','-2','abc','Infinity','5001','1e3','2.333'])assert.equal(parseQuantity(value),null);});
