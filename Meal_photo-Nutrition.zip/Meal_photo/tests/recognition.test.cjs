const test=require('node:test'),assert=require('node:assert/strict');
const {validResult,prepareMeal}=require('../src/recognition.cjs');
test('new protocol accepts no detection and rejects old category API',()=>{
 assert.equal(validResult({apiVersion:2,imageWidth:100,imageHeight:100,detections:[]}),true);
 assert.equal(validResult({candidates:[{label:'pizza',score:.7}]}),false);
 assert.equal(validResult({apiVersion:2,imageWidth:100,imageHeight:100,detections:[{label:'Rice',score:.8,box:[1,0,0,1]}]}),false);
});
test('saving requires explicit confirmation of all foods',()=>{
 assert.throws(()=>prepareMeal([]));
 assert.throws(()=>prepareMeal([{name:'Poulet',confirmed:false,grams:''}]));
 assert.throws(()=>prepareMeal([{name:' ',confirmed:true,grams:''}]));
});
test('confirmed meal requires a sourced profile and grams',()=>{
 const result=prepareMeal([{name:'Poulet',confirmed:true,grams:'100',foodId:'171477',source:'detector'},{name:'Riz',confirmed:true,grams:'125,5',foodId:'168878',source:'manual'}]);
 assert.equal(result.length,2);assert.equal(result[0].nutrition.calories,165);
 assert.equal(result[1].grams,125.5);assert.equal(result[1].quantitySource,'user');
 assert.throws(()=>prepareMeal([{name:'Riz',confirmed:true,grams:'-1',foodId:'168878'}]));
 assert.throws(()=>prepareMeal([{name:'Riz',confirmed:true,grams:'100'}]));
});
test('multiple broccoli regions become one editable food with all regions',()=>{
 const {groupDetections}=require('../src/recognition.cjs');
 const rows=groupDetections([{label:'Brocoli',score:.6,box:[0,0,.2,.2]},{label:'Riz',score:.7,box:[.2,.2,.5,.5]},{label:'Brocoli',score:.8,box:[.6,.6,1,1]}]);
 assert.equal(rows.length,2);assert.equal(rows[0].boxes.length,2);assert.equal(rows[0].score,.8);assert.equal(rows[0].confirmed,false);
});
