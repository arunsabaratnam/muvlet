@echo off
setlocal
cd /d "%~dp0"
title Muvlet - Reconnaissance gratuite
if not exist recognition_server\.venv\Scripts\python.exe (
 py -3.11 -m venv recognition_server\.venv
 if errorlevel 1 (
  echo Installe Python 3.11 pour Windows depuis python.org puis relance ce fichier.
  pause
  exit /b 1
 )
)
call recognition_server\.venv\Scripts\python.exe -m ensurepip --upgrade
if errorlevel 1 goto erreur
call recognition_server\.venv\Scripts\python.exe -m pip install -r recognition_server\requirements.txt
if errorlevel 1 goto erreur
call recognition_server\.venv\Scripts\python.exe recognition_server\server.py
:erreur
pause
