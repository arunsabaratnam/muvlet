@echo off
setlocal
cd /d "%~dp0"
title Muvlet - Meal Photo
where node >nul 2>nul
if errorlevel 1 (
 echo Installe Node.js LTS depuis https://nodejs.org puis relance ce fichier.
 pause
 exit /b 1
)
node -e "const v=process.versions.node.split('.').map(Number);process.exit(v[0]>22||(v[0]===22&&v[1]>=13)?0:1)"
if errorlevel 1 (
 echo Node.js est trop ancien. Installe Node.js LTS depuis https://nodejs.org.
 pause
 exit /b 1
)
if not exist node_modules\expo\package.json (
 echo Installation des composants. Cela peut prendre quelques minutes...
 call npm install
 if errorlevel 1 goto erreur
 call npx expo install --fix
 if errorlevel 1 goto erreur
)
echo Ouvre Expo Go sur ton telephone. Garde cette fenetre ouverte.
call npx expo start --go --clear
if errorlevel 1 goto erreur
exit /b 0
:erreur
echo Une erreur est survenue. Copie le message et envoie-le dans la conversation.
pause
exit /b 1
